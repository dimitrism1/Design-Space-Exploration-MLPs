//Numpy array shape [9]
//Min -0.109375000000
//Max 0.250000000000
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
bias2_t b2[9];
#else
bias2_t b2[9] = {0.1484375, 0.1796875, -0.0937500, 0.1015625, -0.1093750, 0.1484375, 0.1093750, -0.0859375, 0.2500000};
#endif

#endif
