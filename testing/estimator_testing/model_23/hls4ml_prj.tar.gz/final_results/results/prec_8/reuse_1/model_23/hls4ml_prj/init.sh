#!/bin/sh

source /tools/Xilinx/Vitis_HLS/2022.1/settings64.sh
vitis_hls -f build_prj_orig.tcl
