//Numpy array shape [5]
//Min -1.250000000000
//Max 1.250000000000
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[5];
#else
bias11_t b11[5] = {-0.250, 1.250, -1.250, 0.500, -0.125};
#endif

#endif
